/* Boost numeric/odeint/examples/lorenz_stepper.cpp
 
 Copyright 2009 Karsten Ahnert
 Copyright 2009 Mario Mulansky

 Shows the usage of odeint, and integrates the Lorenz equations,
 a deterministic chaotic system

 dx/dt = sigma * ( x - y)
 dy/dt = R*x - y - x*z
 dz/dt = x*y - b*z

 with sigma = 10, r=28, b = 8/3

 Furthermore, the usage of std::tr1::array and std::vector in odeint is
 shown and the performance of both containers is compared.
*/

#include <iostream>
#include <tr1/array>

#include <odeint.hpp>

#define tab "\t"

using namespace std;
using namespace odeint;


typedef std::tr1::array< double , 3 > state_type;

const double sigma = 10.0;
const double R = 28.0;
const double b = 8.0 / 3.0;

void lorenz( state_type &x , state_type &dxdt , double t )
{
    dxdt[0] = sigma * ( x[1] - x[0] );
    dxdt[1] = R * x[0] - x[1] - x[0] * x[2];
    dxdt[2] = x[0]*x[1] - b * x[2];
}

class lorenz_class
{
 public:
    void operator()( state_type &x , state_type &dxdt , double t )
    {
        dxdt[0] = sigma * ( x[1] - x[0] );
        dxdt[1] = R * x[0] - x[1] - x[0] * x[2];
        dxdt[2] = x[0]*x[1] - b * x[2];
    }
};

int main( int argc , char **argv )
{
    const double dt = 0.01;
    
    state_type x = {{ 1.0 , 0.0 , 0.0 }};
    ode_step_euler< state_type > stepper;

    double t = 0.0;
    for( size_t oi=0 ; oi<10000 ; ++oi,t+=dt )
    {
	stepper.next_step( lorenz , x , t , dt );
	cout << x[0] << tab << x[1] << tab << x[2] << endl;
    }

    return 0;
}



/*
  Compile with
  g++ -Wall -O3 -I$BOOST_ROOT -I../../../../ lorenz_stepper.cpp
*/
