/* Boost odeint/runge_kutta_4.hpp header file
 
 Copyright 2009 Karsten Ahnert
 Copyright 2009 Mario Mulansky
 Copyright 2009 Andre Bergner
 
 This file includes the explicit runge kutta solver for
 ordinary differential equations.

 It solves any ODE dx/dt = f(x,t).
*/

#ifndef BOOST_NUMERIC_ODEINT_RUNGE_KUTTA_4_HPP
#define BOOST_NUMERIC_ODEINT_RUNGE_KUTTA_4_HPP

#include <odeint/resizer.hpp>
#include <iostream>

namespace odeint {


    template<
        class Container ,
	class Time = double ,
        class Resizer = resizer< Container >
        >
    class ode_step_runge_kutta_4
    {

        // provide basic typedefs
    public:

        typedef Container container_type;
        typedef Resizer resizer_type;
        typedef Time time_type;
	typedef const unsigned short order_type;
        typedef typename container_type::value_type value_type;
        typedef typename container_type::iterator iterator;





        // private members
    private:

        container_type m_dxdt;
        container_type m_dxt;
        container_type m_dxm;
        container_type m_xt;
        resizer_type m_resizer;

        



	// public interface
    public:

	order_type order() const { return 4; }

        template< class DynamicalSystem >
        void next_step( DynamicalSystem &system ,
                        container_type &x ,
                        const container_type &dxdt ,
                        time_type t ,
                        time_type dt )
        {
	    using namespace detail::it_algebra;

            const time_type val2 = time_type( 2.0 );

	    m_resizer.adjust_size( x , m_dxt );
	    m_resizer.adjust_size( x , m_dxm );
	    m_resizer.adjust_size( x , m_xt );

            time_type  dh = time_type( 0.5 ) * dt;
            time_type th = t + dh;

	    assign_sum( m_xt.begin() , m_xt.end() , x.begin() , dxdt.begin() , dh );

            system( m_xt , m_dxt , th );
	    assign_sum( m_xt.begin() , m_xt.end() , x.begin() , m_dxt.begin() , dh );

            system( m_xt , m_dxm , th );
	    assign_sum_increment( m_xt.begin() , m_xt.end() , x.begin() ,
				  m_dxm.begin() , m_dxt.begin() , dt );

            system( m_xt , m_dxt , value_type( t + dt ) );
	    increment_sum_sum( x.begin() , x.end() , dxdt.begin() ,
			       m_dxt.begin() , m_dxm.begin() ,
			       dt /  time_type( 6.0 ) , val2 );
        }



        template< class DynamicalSystem >
        void next_step( DynamicalSystem &system ,
                        container_type &x ,
                        time_type t ,
                        time_type dt )
        {
	    m_resizer.adjust_size( x , m_dxdt );
	    system( x , m_dxdt , t );
	    next_step( system , x , m_dxdt , t , dt );
        }


    };

} // namespace odeint


#endif // BOOST_NUMERIC_ODEINT_RUNGE_KUTTA_4_HPP
